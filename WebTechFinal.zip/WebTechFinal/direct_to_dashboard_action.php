<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (isset($_SESSION['userID'])) {
    // User is already logged in, redirect to dashboard
    header("Location: application_management.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email and password (You should add more validation)
    // Assuming you already have a table called "Users" with columns "Email" and "Password"
    $sql = "SELECT * FROM Users WHERE Email = ?";
    $stmt = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_assoc($result)) {
            // Verify password
            if (password_verify($password, $row['Password'])) {
                // Password is correct, set session variables
                $_SESSION['userID'] = $row['UserID'];
                // Redirect to dashboard
                header("Location: application_management.php");
                exit();
            } else {
                // Password is incorrect
                $error = "Invalid email or password.";
            }
        } else {
            // Email not found
            $error = "Invalid email or password.";
        }
    } else {
        // Database query error
        $error = "Error connecting to the database.";
    }
}
?>
