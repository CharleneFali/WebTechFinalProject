<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

// Fetch au pair profile information from the database
// Fetch the au pair's profile information from the database
//$sql = "SELECT * FROM Profiles WHERE UserID = ? ";
// Fetch the au pair's profile information from the database
$sql = "SELECT Profiles.* FROM Profiles JOIN Users ON Profiles.UserID = Users.UserID WHERE Users.UserType = 'Au Pair' AND Profiles.UserID = ?";
$stmt = mysqli_stmt_init($conn);
if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['userID']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Au Pair Profile</title>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }
    .container {
        width: 800px;
        margin: 50px auto;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        padding: 40px;
        box-sizing: border-box;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    .profile-info {
        margin-bottom: 20px;
    }
    .profile-info label {
        display: block;
        margin-bottom: 5px;
        color: #777;
    }
    .profile-info input[type="text"] {
        width: 100%;
        padding: 8px;
        border-radius: 5px;
        border: 1px solid #ddd;
        box-sizing: border-box;
    }
    .profile-info input[type="submit"] {
        background: #ff6b6b;
        border: none;
        padding: 10px;
        border-radius: 5px;
        color: #fff;
        cursor: pointer;
        transition: background 0.3s;
    }
    .profile-info input[type="submit"]:hover {
        background: #ff8e8e;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Au Pair Profile</h2>
    <form action="edit_profile.php" method="post">
        <div class="profile-info">
            <label for="firstName">FirstName:</label>
            <input type="text" id="firstName" name="firstName" value="Dorian">
        </div>
        <div class="profile-info">
            <label for="lastName">LastName:</label>
            <input type="text" id="lastName" name="lastName" value="Doe">
        </div>
        <div class="profile-info">
            <label for="dateOfBirth">Date of Birth:</label>
            <input type="date" id="dateOfBirth" name="dateOfBirth" value="1999-01-01">
        </div>
        <div class="profile-info">
            <label for="nationality">Nationality:</label>
            <input type="text" id="nationality" name="nationality" value="Teal">
        </div>
        <div class="profile-info">
            <label for="experienceYears">Experience:</label>
            <input type="text" id="experienceYears" name="experienceYears" value="2 years">
        </div>
        <div class="profile-info">
            <label for="languageSpoken">Skills:</label>
            <input type="text" id="languageSpoken" name="languageSpoken" value="Childcare, Cooking, Language Teaching">
        </div>
        <div class="profile-info">
            <label for="aboutMe">Preferences:</label>
            <input type="text" id="aboutMe" name="aboutMe" value="Non-smoking family, No pets">
        </div>
        <div class="profile-info">
            <label for="introductionVideoLink">Introduction Video/Photo:</label>
            <input type="file" id="introductionVideoLink" name="introductionVideoLink">
        </div>
        <div class="profile-info">
            <label for="availableFromDate">Availability:</label>
            <input type="text" id="aavailableFromDate" name="availableFromDate" value="Available from September 2024">
        </div>
        <div class="profile-info">
            <label for="location">Preferred Location:</label>
            <input type="text" id="location" name="location" value="Europe">
        </div>
        <div class="profile-info">
            <input type="submit" value="Save Changes">
        </div>
    </form>
    <form action="delete_profile.php" method="post">
        <div class="profile-info">
            <input type="submit" value="Delete Profile" style="background: #ff6b6b;">
        </div>
    </form>
</div>
</body>
</html>

