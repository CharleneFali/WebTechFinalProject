<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the job ID from the form submission
    $jobPostID = $_POST['jobPostID'];

    // Retrieve the user ID of the applicant from the session
    $userID = $_SESSION['userID'];

    // Insert a new record into the Applications table
    $sql = "INSERT INTO Applications (JobPostID, AuPairUserID, ApplicationDate, Status) VALUES (?, ?, NOW(), 'Applied')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $jobPostID, $userID);

    if ($stmt->execute()) {
        // Application successful
        $message = "Your application has been submitted successfully.";
    } else {
        // Application failed
        $message = "Sorry, there was an error processing your application.";
    }
}

// Redirect back to the job posts page with a message
header("Location: job_posts.php?message=" . urlencode($message));
exit();
?>
