<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reviewerID = $_POST['reviewer'];
    $revieweeID = $_POST['reviewee'];
    $rating = $_POST['rating'];
    $review = $_POST['review'];

    // Insert the review into the database
    $sql = "INSERT INTO Reviews (AuthorUserID, TargetUserID, Rating, Comment, ReviewDate) VALUES (?, ?, ?, ?, NOW())";
    $stmt = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, "iiis", $reviewerID, $revieweeID, $rating, $review);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
        header("Location: reviews_feedback.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
