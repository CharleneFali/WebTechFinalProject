<?php
session_start();
include_once 'db_connection.php';

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['userID'])) {
    $userID = $_GET['userID'];
    
    // Fetch profile information based on the provided user ID
    $sql = "SELECT * FROM Profiles WHERE UserID = ?";
    $stmt = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $userID);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_assoc($result)) {
            // Display the profile details
            echo "<h2>User Profile</h2>";
            echo "<p>Name: " . $row['FirstName'] . " " . $row['LastName'] . "</p>";
            echo "<p>Email: " . $row['Email'] . "</p>";
            echo "<p>Location: " . $row['Location'] . "</p>";
            // Display more profile details as needed
            // Add edit and delete buttons if the current user is the owner of the profile
            if ($_SESSION['userID'] == $userID) {
                echo '<a href="edit_profile.php?userID=' . $userID . '">Edit Profile</a>';
                echo '<form action="delete_profile.php" method="post">';
                echo '<input type="hidden" name="userID" value="' . $userID . '">';
                echo '<button type="submit">Delete Profile</button>';
                echo '</form>';
            }
        } else {
            echo "Profile not found.";
        }
    } else {
        echo "Error fetching profile details.";
    }
} else {
    header("Location: dashboard.php"); // Redirect if userID is not provided
    exit();
}
?>
