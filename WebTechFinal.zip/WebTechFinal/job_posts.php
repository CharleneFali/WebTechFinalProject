<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Fetch available job posts from the database
$sql = "SELECT * FROM JobPosts";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Job Posts</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    .back-to-dashboard {
      display: inline-block;
      padding: 10px 20px;
      background-color: coral;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .back-to-dashboard:hover {
      background-color: #ff6b6b; 
    }
  </style>

</head>
<body>

  <!-- Job Posts -->
  <section class="job-posts">
    <h2>Available Job Posts</h2>
    <ul>
      <?php
        // Display job posts
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<li>";
          echo "<h3>{$row['Title']}</h3>";
          echo "<p><strong>Description:</strong> {$row['Description']}</p>";
          echo "<p><strong>Location:</strong> {$row['Location']}</p>";
          echo "<p><strong>Start Date:</strong> {$row['StartDate']}</p>";
          echo "<p><strong>Duration:</strong> {$row['Duration']}</p>";
          echo "<p><strong>Compensation:</strong> {$row['Compensation']}</p>";
          echo "<form method='post' action='apply_job.php'>";
          echo "<input type='hidden' name='jobPostID' value='{$row['JobPostID']}'>";
          echo "<button type='submit'>Apply</button>";
          echo "</form>";
          echo "</li>";
        }
        // Close database connection
        mysqli_close($conn);
      ?>
    </ul>
    <a href="application_management.php" class="back-to-dashboard">Back to Dashboard</a>

  </section>

</body>
</html>
