<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID
$loggedInUserId = $_SESSION['userID'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $dateOfBirth = $_POST['dateOfBirth'];
    $nationality = $_POST['nationality'];
    $experienceYears = $_POST['experienceYears'];
    $languageSpoken = $_POST['languageSpoken'];
    $aboutMe = $_POST['aboutMe'];
    // Process other form fields as needed

    // Update the profile information in the database
    $sql = "UPDATE Profiles SET firstName='$firstName', lastName='$lastName', dateOfBirth='$dateOfBirth', nationality='$nationality', experienceYears='$experienceYears', languageSpoken='$languageSpoken', aboutMe='$aboutMe' WHERE userID = $loggedInUserId"; 
    if ($conn->query($sql) === TRUE) {
        echo "Profile updated successfully";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}
?>
