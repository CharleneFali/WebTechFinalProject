<?php
// Assuming you have already connected to the database in your config.php file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Perform delete operation based on the logged-in user's ID
    $sql = "DELETE FROM au_pair_profiles WHERE user_id = $loggedInUserId"; // Modify the query to match your database structure and the logged-in user's ID
    if ($conn->query($sql) === TRUE) {
        echo "Profile deleted successfully";
    } else {
        echo "Error deleting profile: " . $conn->error;
    }
}
?>
