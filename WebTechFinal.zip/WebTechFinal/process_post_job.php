<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $start_date = $_POST['start_date'];
    $duration = $_POST['duration'];
    $compensation = $_POST['compensation'];

    // Insert job posting into the database
    $sql = "INSERT INTO JobPosts (Title, Description, Location, StartDate, Duration, Compensation) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdd", $title, $description, $location, $start_date, $duration, $compensation);

    if ($stmt->execute()) {
        // Job posting successful
        $message = "Job posted successfully.";
    } else {
        // Job posting failed
        $message = "Sorry, there was an error posting the job.";
    }

    // Redirect back to the post a job page with a message
    header("Location: post_a_job.php?message=" . urlencode($message));
    exit();
}
?>
