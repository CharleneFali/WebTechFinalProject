<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

// Fetch reviews and ratings from the database
$sql = "SELECT * FROM Reviews WHERE AuthorUserID = ?";
$stmt = mysqli_stmt_init($conn);
if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['userID']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reviews and Feedback</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    
    .btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: coral;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .btn:hover {
      background-color: #ff6b6b;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      padding: 0;
    }

    .reviews-feedback {
      max-width: 800px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      color: #333;
      margin-top: 0;
      margin-bottom: 20px;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      margin-bottom: 20px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      color: #555;
    }

    input[type="text"],
    input[type="number"],
    textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    button[type="submit"] {
      background-color: coral;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button[type="submit"]:hover {
      background-color: #ff6b6b;
    }
  </style>
</head>
<body>

  <!-- Reviews and Feedback -->
  <section class="reviews-feedback">
    <h2>Reviews and Ratings</h2>
    <ul>
      <?php
        // Display reviews and ratings
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<li>";
          echo "<p><strong>From:</strong> {$row['ReviewerID']}</p>";
          echo "<p><strong>Rating:</strong> {$row['Rating']}</p>";
          echo "<p><strong>Review:</strong> {$row['Review']}</p>";
          echo "</li>";
        }
      ?>
    </ul>
    <h2>Leave Review and Rating</h2>
    <form method="post" action="leave_review.php">
      <label for="reviewer">From:</label><br>
      <input type="text" id="reviewer" name="reviewer" value="<?php echo $_SESSION['userID']; ?>" readonly><br>
      <label for="reviewee">To:</label><br>
      <input type="text" id="reviewee" name="reviewee"><br>
      <label for="rating">Rating:</label><br>
      <input type="number" id="rating" name="rating" min="1" max="5"><br>
      <label for="review">Review:</label><br>
      <textarea id="review" name="review" rows="4" cols="50"></textarea><br>
      <button type="submit">Submit</button>
    </form>
    <h2>Feedback Form</h2>
    <form method="post" action="submit_feedback.php">
      <label for="feedback">Feedback:</label><br>
      <textarea id="feedback" name="feedback" rows="4" cols="50"></textarea><br>
      <button type="submit">Submit Feedback</button>
    </form>
    <a href="application_management.php" class="btn">Back to Dashboard</a>
  </section>

</body>
</html>