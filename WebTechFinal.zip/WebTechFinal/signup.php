<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is already logged in, redirect to homepage if true
if (isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit();
}

// Initialize variables for registration form
$email = $password = $userType = "";
$registerError = "";

// Check if the registration form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input from the form
    $email = $_POST['email'];
    $password = $_POST['password'];
    $userType = $_POST['userType'];

    // Validate user input
    if (empty($email) || empty($password) || empty($userType)) {
        $registerError = "Please fill in all fields.";
    } else {
        // Check if the email is already registered
        $sql = "SELECT UserID FROM Users WHERE Email=?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            $registerError = "SQL statement error: " . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultCheck = mysqli_stmt_num_rows($stmt);
            if ($resultCheck > 0) {
                $registerError = "Email is already taken.";
            } else {
                // Hash the password before storing in the database
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                // Insert new user into the database
                $sql = "INSERT INTO Users (Email, Password, UserType, RegistrationDate) VALUES (?, ?, ?, NOW())";
                $stmt = mysqli_stmt_init($conn);
                if (!mysqli_stmt_prepare($stmt, $sql)) {
                    $registerError = "SQL statement error: " . mysqli_error($conn);
                } else {
                    mysqli_stmt_bind_param($stmt, "sss", $email, $hashedPassword, $userType);
                    mysqli_stmt_execute($stmt);
                    // Redirect to login page after successful registration
                    header("Location: login.html?signup=success");
                    exit();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up</title>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }
    .container {
        width: 360px;
        margin: 100px auto;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        padding: 40px;
        box-sizing: border-box;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    .input-group {
        margin-bottom: 20px;
    }
    .input-group label {
        display: block;
        margin-bottom: 5px;
        color: #777;
    }
    .input-group input {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ddd;
        box-sizing: border-box;
    }
    .input-group input:focus {
        outline: none;
        border-color: #00a896; /* Teal color */
    }
    .btn {
        width: 100%;
        background: #ff6b6b; /* Coral color */
        border: none;
        padding: 10px;
        border-radius: 5px;
        color: #fff;
        cursor: pointer;
        transition: background 0.3s;
    }
    .btn:hover {
        background: #ff8e8e; /* Lighter coral color on hover */
    }
    .error-msg {
        color: #ff6b6b; /* Coral color */
        margin-top: 10px;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Sign Up</h2>
    <form action="signup.php" method="post" onsubmit="return validateSignUpForm()">
        <div class="input-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="input-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="input-group">
            <label for="userType">User Type:</label>
            <select id="userType" name="userType" required>
                <option value="">Select User Type</option>
                <option value="Au Pair">Au Pair</option>
                <option value="Family">Family</option>
            </select>
        </div>
        <button type="submit" class="btn">Sign Up</button>
        <p class="error-msg" id="error-msg"></p>
    </form>
    <p>Already have an account? <a href="login.html">Login here</a>.</p>
</div>

<script>
    function validateSignUpForm() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var userType = document.getElementById('userType').value;
        var errorMsg = document.getElementById('error-msg');

        if (email.trim() === '' || password.trim() === '' || userType.trim() === '') {
            errorMsg.textContent = 'Please enter all fields.';
            return false;
        }

        
        return true;
    }
</script>
</body>
</html>
