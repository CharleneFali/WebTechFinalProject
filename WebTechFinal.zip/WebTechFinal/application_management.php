<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

// Fetch applications made by the au pair from the database
// Fetch applications made by the au pair from the database
$sql = "SELECT Applications.*, JobPosts.Title AS JobTitle, JobPosts.Location, JobPosts.StartDate, JobPosts.Duration, JobPosts.Compensation FROM Applications JOIN JobPosts ON Applications.JobPostID = JobPosts.JobPostID WHERE Applications.AuPairUserID = ?";
$stmt = mysqli_stmt_init($conn);
if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['AuPairUserID']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f7f7;
    }

    .sidebar {
      background-color: teal;
      color: #fff;
      width: 250px;
      height: 100vh;
      padding-top: 20px;
      position: fixed;
      left: 0;
      top: 0;
    }

    .sidebar h2 {
      margin-bottom: 30px;
      padding-left: 20px;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar li {
      margin-bottom: 10px;
    }

    .sidebar a {
      display: block;
      color: #fff;
      text-decoration: none;
      padding: 10px 20px;
      transition: background-color 0.3s;
    }

    .sidebar a:hover {
      background-color: #196f6f;
    }

    .content {
      margin-left: 250px;
      padding: 20px;
    }

    .dashboard {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .dashboard h2 {
      margin-top: 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: coral;
      color: #fff;
    }

    td {
      text-align: center;
    }

  </style>
</head>
<body>

  <!-- Sidebar -->
  <aside class="sidebar">
    <h2>Dashboard</h2>
    <ul>
      <li><a href="profile.php">View Profile</a></li>
      <li><a href="job_posts.php">View Job Posts</a></li>
      <li><a href="post_a_job.php">Post a Job</a></li>
      <li><a href="application_management.php">Application Management</a></li>
      <li><a href="messaging.php">Messaging</a></li>
      <li><a href="reviews_feedback.php">Reviews and Feedback</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </aside>

  <!-- Main Content -->
  <main class="content">
    <!-- Application Management Dashboard -->
    <section class="dashboard">
      <h2>Application Management</h2>
      <table>
        <tr>
          <th>Job Title</th>
          <th>Location</th>
          <th>Start Date</th>
          <th>Duration</th>
          <th>Compensation</th>
          <th>Status</th>
        </tr>
        <?php
          // Display applications
          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['JobTitle']}</td>";
            echo "<td>{$row['Location']}</td>";
            echo "<td>{$row['StartDate']}</td>";
            echo "<td>{$row['Duration']}</td>";
            echo "<td>{$row['Compensation']}</td>";
            echo "<td>{$row['Status']}</td>";
            echo "</tr>";
          }
          // Close database connection
          mysqli_close($conn);
        ?>
      </table>
    </section>
  </main>

</body>
</html>
