<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Post a Job</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    .btn {
  display: inline-block;
  padding: 10px 20px;
  background-color: coral;
  color: #fff;
  text-decoration: none;
  border-radius: 5px;
  transition: background-color 0.3s;
}

.btn:hover {
  background-color: #ff6b6b;
}

    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      margin-top: 0;
      margin-bottom: 20px;
      color: #333;
    }

    label {
      display: block;
      margin-bottom: 5px;
      color: #555;
    }

    input[type="text"],
    input[type="date"],
    input[type="number"],
    textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    button[type="submit"] {
      background-color: coral;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button[type="submit"]:hover {
      background-color: #ff6b6b;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Post a Job</h2>
    <form action="process_post_job.php" method="post">
      <label for="title">Title:</label>
      <input type="text" id="title" name="title" required>

      <label for="description">Description:</label>
      <textarea id="description" name="description" rows="4" required></textarea>

      <label for="location">Location:</label>
      <input type="text" id="location" name="location" required>

      <label for="start_date">Start Date:</label>
      <input type="date" id="start_date" name="start_date" required>

      <label for="duration">Duration (in months):</label>
      <input type="number" id="duration" name="duration" min="1" required>

      <label for="compensation">Compensation:</label>
      <input type="number" id="compensation" name="compensation" min="0" step="0.01" required>

      <button type="submit">Post Job</button>
    </form>
    <a href="application_management.php" class="btn">Back to Dashboard</a>
  </div>

</body>
</html>
