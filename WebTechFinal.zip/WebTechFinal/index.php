<?php
session_start(); // Start PHP session
include_once 'db_connection.php'; // Include database connection script

// Fetch featured job posts or au pairs from the database (sample data)
$sql = "SELECT * FROM JobPosts LIMIT 3";
$result = mysqli_query($conn, $sql);

// Check if the user is logged in
if (isset($_SESSION['userID'])) {
    // Redirect logged-in users to their respective dashboard
    if ($_SESSION['userType'] == 'Au Pair') {
        header("Location: au_pair_dashboard.php");
        exit();
    } elseif ($_SESSION['userType'] == 'Family') {
        header("Location: family_dashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Au Pair Hiring Website</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>

  <!-- Welcome section -->
  <header>
    <h1>Welcome to Au Pair Hiring</h1>
    <p>Find your perfect match for au pair services or host families.</p>
  </header>

  <!-- Sign-up/Login options -->
  <section class="signup-login">
    <h2>Sign Up / Login</h2>
    <p>New to our platform? <a href="signup.php">Sign up here</a></p>
    <p>Already have an account? <a href="login.php">Login here</a></p>
  </section>

  <!-- Featured job posts or au pairs -->
  <section class="featured">
    <h2>Featured Job Posts</h2>
    <ul>
      <?php
        // Display job posts
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<li>{$row['Title']} - {$row['Description']}</li>";
        }
        // Close database connection
        mysqli_close($conn);
      ?>
    </ul>
  </section>

</body>
</html>
