DROP database if exists au_pair_hiring_website;
-- Create the database
CREATE DATABASE au_pair_hiring_website;

-- Use the created database
USE au_pair_hiring_website;

-- Create the Users table
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(255) UNIQUE,
    Password VARCHAR(255),
    UserType ENUM('Au Pair', 'Family'),
    RegistrationDate DATETIME,
    LastLogin DATETIME
);

-- Create the Profiles table
CREATE TABLE Profiles (
    ProfileID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT UNIQUE,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    DateOfBirth DATE,
    Nationality VARCHAR(255),
    Location VARCHAR(255),
    IntroductionVideoLink VARCHAR(255),
    AboutMe TEXT,
    ExperienceYears INT,
    AvailableFromDate DATE,
    LanguageSpoken VARCHAR(255),
    PreferredCountry VARCHAR(255),
    ProfileCreationDate DATETIME,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Create the BackgroundChecks table
CREATE TABLE BackgroundChecks (
    CheckID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    CheckType VARCHAR(50),
    CheckDate DATE,
    CheckStatus ENUM('Pending', 'Clear', 'Issues'),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Create the JobPosts table
CREATE TABLE JobPosts (
    JobPostID INT AUTO_INCREMENT PRIMARY KEY,
    FamilyUserID INT,
    Title VARCHAR(255),
    Description TEXT,
    PostedDate DATETIME,
    StartDate DATE,
    Duration INT,
    Location VARCHAR(255),
    Compensation DECIMAL(10, 2),
    FOREIGN KEY (FamilyUserID) REFERENCES Users(UserID)
);

-- Create the Applications table
CREATE TABLE Applications (
    ApplicationID INT AUTO_INCREMENT PRIMARY KEY,
    JobPostID INT,
    AuPairUserID INT,
    ApplicationDate DATETIME,
    Status ENUM('Applied', 'Accepted', 'Rejected'),
    FOREIGN KEY (JobPostID) REFERENCES JobPosts(JobPostID),
    FOREIGN KEY (AuPairUserID) REFERENCES Users(UserID)
);

-- Create the Messages table
CREATE TABLE Messages (
    MessageID INT AUTO_INCREMENT PRIMARY KEY,
    SenderUserID INT,
    ReceiverUserID INT,
    MessageText TEXT,
    SentDate DATETIME,
    ReadStatus BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (SenderUserID) REFERENCES Users(UserID),
    FOREIGN KEY (ReceiverUserID) REFERENCES Users(UserID)
);

-- Create the Reviews table
CREATE TABLE Reviews (
    ReviewID INT AUTO_INCREMENT PRIMARY KEY,
    AuthorUserID INT,
    TargetUserID INT,
    JobPostID INT,
    Rating INT,
    Comment TEXT,
    ReviewDate DATETIME,
    FOREIGN KEY (AuthorUserID) REFERENCES Users(UserID),
    FOREIGN KEY (TargetUserID) REFERENCES Users(UserID),
    FOREIGN KEY (JobPostID) REFERENCES JobPosts(JobPostID)
);
