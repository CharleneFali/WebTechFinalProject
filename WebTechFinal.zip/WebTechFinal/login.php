<?php
session_start(); // Start the PHP session
include_once 'db_connection.php'; // Include database connection script

// Check if the user is already logged in, redirect to homepage if true
if (isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit();
}

// Initialize variables for login form
$email = "";
$password = "";
$loginError = "";

// Check if the login form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input from the form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate user input
    if (empty($email) || empty($password)) {
        $loginError = "Please enter both email and password.";
    } else {
        // Prepare SQL statement to fetch user from database
        $sql = "SELECT * FROM Users WHERE Email=?;";
        $stmt = mysqli_stmt_init($conn);

        // Check if SQL statement is valid
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            $loginError = "SQL statement error.";
        } else {
            // Bind parameters to the prepared statement
            mysqli_stmt_bind_param($stmt, "s", $email);
            // Execute the prepared statement
            mysqli_stmt_execute($stmt);
            // Get result from the executed statement
            $result = mysqli_stmt_get_result($stmt);

            // Check if a user with the given email exists
            if ($row = mysqli_fetch_assoc($result)) {
                // Verify the password
                $passwordCheck = password_verify($password, $row['Password']);
                if ($passwordCheck == false) {
                    $loginError = "Incorrect password.";
                } else if ($passwordCheck == true) {
                    // Password is correct, start a new session
                    session_start();
                    // Store user data in session variables
                    $_SESSION['userID'] = $row['UserID'];
                    $_SESSION['userType'] = $row['UserType'];
                    // Redirect to homepage after successful login
                    header("Location: index.php");
                    exit();
                }
            } else {
                // No user found with the given email
                $loginError = "No user found with this email.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }
    .container {
        width: 360px;
        margin: 100px auto;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        padding: 40px;
        box-sizing: border-box;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    .input-group {
        margin-bottom: 20px;
    }
    .input-group label {
        display: block;
        margin-bottom: 5px;
        color: #777;
    }
    .input-group input {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ddd;
        box-sizing: border-box;
    }
    .input-group input:focus {
        outline: none;
        border-color: #00a896; 
    }
    .btn {
        width: 100%;
        background: #ff6b6b; 
        border: none;
        padding: 10px;
        border-radius: 5px;
        color: #fff;
        cursor: pointer;
        transition: background 0.3s;
    }
    .btn:hover {
        background: #ff8e8e; 
    }
    .error-msg {
        color: #ff6b6b;
        margin-top: 10px;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Login</h2>
    <form action="direct_to_dashboard.php" method="post" onsubmit="return validateLoginForm()">
        <div class="input-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="input-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn">Login</button>
        <p class="error-msg" id="error-msg"></p>
    </form>
    <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
</div>

<script>
    function validateLoginForm() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var errorMsg = document.getElementById('error-msg');

        if (email.trim() === '' || password.trim() === '') {
            errorMsg.textContent = 'Please enter both email and password.';
            return false;
        }

        // You can add more validation here if needed

        return true;
    }
</script>
</body>
</html>
